<?php
namespace Common\Model;

class IndxModel extends \Think\Model
{
	public function __construct()
	{
		parent::__construct();
	}
}

?>