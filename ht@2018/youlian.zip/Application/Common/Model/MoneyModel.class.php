<?php
namespace Common\Model;

class MoneyModel extends \Think\Model
{
	protected $keyS = 'Money';
}

?>