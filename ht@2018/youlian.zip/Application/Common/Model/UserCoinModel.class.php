<?php
namespace Common\Model;

class UserCoinModel extends \Think\Model
{
	public function get_coin($field = NULL)
	{
	}
}

?>