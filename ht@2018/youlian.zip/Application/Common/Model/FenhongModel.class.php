<?php
namespace Common\Model;

class FenhongModel extends \Think\Model
{
	protected $keyS = 'Fenhong';
}

?>