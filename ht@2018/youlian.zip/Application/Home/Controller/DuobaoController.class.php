<?php
namespace Home\Controller;

class DuobaoController extends HomeController
{
	public function index()
	{
		$this->display();
	}


    
}

?>